npm install express 
npm install body-parser 
npm install mariadb
npm init